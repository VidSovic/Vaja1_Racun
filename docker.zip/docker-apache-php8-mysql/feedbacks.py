from requests_html import HTMLSession
from websockets import client

session = HTMLSession()

#CHANGE THIS IF NEEDED
web_site='http://192.168.240.128:8000'
web_ip='192.168.240.128'
proxies = {'http': 'http://192.168.240.1:8080'}
######################

burp0_url = web_site+"/login.php"
burp0_headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:104.0) Gecko/20100101 Firefox/104.0", "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8", "Accept-Language": "en-GB,en;q=0.5", "Accept-Encoding": "gzip, deflate", "Content-Type": "application/x-www-form-urlencoded", "Origin": "http://localhost", "Connection": "close", "Referer": "http://localhost/Dubai/login.php", "Upgrade-Insecure-Requests": "1", "Sec-Fetch-Dest": "document", "Sec-Fetch-Mode": "navigate", "Sec-Fetch-Site": "same-origin", "Sec-Fetch-User": "?1"}
burp0_data = {"username": "admin", "password": "6z&JL9B%hyHWH#", "poslji": ''}

r = session.post(burp0_url, data=burp0_data)
#r = session.post(burp0_url, data=burp0_data, proxies=proxies)

cookie = session.cookies.get_dict()
cookie_PHP = session.cookies.get_dict()["PHPSESSID"]

r = session.get(web_site+'/600208e68f2fd28ea63be052666b2a65.php', cookies=cookie)
#r = session.get(web_site+'/600208e68f2fd28ea63be052666b2a65.php', proxies=proxies, cookies=cookie)
r.html.render(cookies=[{'name': 'PHPSESSID', 'value': cookie_PHP, 'domain': web_ip}])

r = session.get(web_site+'/abca989e5ebd057838d1d904b19ba3c1.php', cookies=cookie)
#r = session.get(web_site+'/abca989e5ebd057838d1d904b19ba3c1.php', cookies=cookie, proxies=proxies)

page_html = r.html
list = page_html.find('p')

for item in list:
        r = session.get(web_site+'/a22ad419fe378662b71eea451e68d179.php?id='+item.text,cookies=cookie)
        #r = session.get(web_site+'/a22ad419fe378662b71eea451e68d179.php?id='+item.text,cookies=cookie, proxies=proxies)
        r.html.render(cookies=[{'name': 'PHPSESSID', 'value': cookie_PHP, 'domain': web_ip}])

r = session.get(web_site+'/a5c0ff01789ae7f96513eea80568bbcd.php', cookies=cookie)

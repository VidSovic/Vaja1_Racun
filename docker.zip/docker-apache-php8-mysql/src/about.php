<?php
include_once('header.php');
?>
<!-- header section end -->
<!-- about section start -->
<div class="about_section layout_padding">
   <div class="container-fluid">
      <div class="row">
         <div class="col-md-6">
            <div class="about_taital_main">
               <h1 style="color:white;" class="about_taital">About Us</h1>
               <p style="color:white;" class="about_text">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All </p>
               <div style="color:white;" class="readmore_bt"><a href="#">Read More</a></div>
            </div>
         </div>
         <div class="col-md-6 padding_right_0">
            <div><img src="images/about-img.png" class="about_img"></div>
         </div>
      </div>
   </div>
</div>
<!-- about section end -->
<!-- footer section start -->
<div class="footer_section layout_padding">
   <div class="container">
      <div class="input_btn_main">
         <input type="text" class="mail_text" placeholder="Enter your email" name="Enter your email">
         <div class="subscribe_bt"><a href="#">Subscribe</a></div>
      </div>
      <div class="location_main">
         <div class="call_text"><img src="images/call-icon.png"></div>
         <div class="call_text"><a href="#">Call +01 1234567890</a></div>
         <div class="call_text"><img src="images/mail-icon.png"></div>
         <div class="call_text"><a href="#">demo@gmail.com</a></div>
      </div>
      <div class="social_icon">
         <ul>
            <li><a href="#"><img src="images/fb-icon.png"></a></li>
            <li><a href="#"><img src="images/twitter-icon.png"></a></li>
            <li><a href="#"><img src="images/linkedin-icon.png"></a></li>
            <li><a href="#"><img src="images/instagram-icon.png"></a></li>
         </ul>
      </div>
   </div>
</div>
<!-- footer section end -->
<!-- copyright section start -->
<div class="copyright_section">
   <div class="container">
      <p class="copyright_text">2020 All Rights Reserved. Design by <a href="https://html.design">Free html Templates</a></p>
   </div>
</div>
</body>

</html>
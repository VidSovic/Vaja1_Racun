<?php
include_once('header.php');

$goals = [];

function get_myplans()
{
  global $conn;
  $id_user = $_SESSION["USER_ID"];
  $query = "SELECT * FROM mygoals WHERE id_user=$id_user;";
  $res = $conn->query($query);
  $goals = array();
  while ($goal = $res->fetch_object()) {
    array_push($goals, $goal);
  }
  return $goals;
}
if (isset($_SESSION["USER_ID"])) {
  $goals = get_myplans();
} else {
  echo "<script>window.location.href='login.php'</script>";
}

function add_plan($plan)
{
  global $conn;
  $plan = mysqli_real_escape_string($conn, $plan);
  $id_user = $_SESSION["USER_ID"];
  $query = "INSERT INTO mygoals (goal, id_user) VALUES ('$plan', '$id_user');";
  if ($conn->query($query)) {
    return true;
  } else {
    echo mysqli_error($conn);
    return false;
  }
}
if (isset($_SESSION["USER_ID"])) {
  if (isset($_POST["myplans"])) {
    if (add_plan($_POST["message"])) {
      echo "<script>window.location.href='myplans.php'</script>";
      die();
    }
  }
}

function xss_clean($data)
{
  // Fix &entity\n;
  $data = str_replace(array('&amp;', '&lt;', '&gt;'), array('&amp;amp;', '&amp;lt;', '&amp;gt;'), $data);
  $data = preg_replace('/(&#*\w+)[\x00-\x20]+;/u', '$1;', $data);
  $data = preg_replace('/(&#x*[0-9A-F]+);*/iu', '$1;', $data);
  $data = html_entity_decode($data, ENT_COMPAT, 'UTF-8');

  // Remove any attribute starting with "on" or xmlns
  //$data = preg_replace('#(<[^>]+?[\x00-\x20"\'])(?:onload|xmlns|)[^>]*+>#iu', '$1>', $data);

  // Remove javascript: and vbscript: protocols
  $data = preg_replace('#([a-z]*)[\x00-\x20]*=[\x00-\x20]*([`\'"]*)[\x00-\x20]*j[\x00-\x20]*a[\x00-\x20]*v[\x00-\x20]*a[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iu', '$1=$2nojavascript...', $data);
  $data = preg_replace('#([a-z]*)[\x00-\x20]*=([\'"]*)[\x00-\x20]*v[\x00-\x20]*b[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iu', '$1=$2novbscript...', $data);
  $data = preg_replace('#([a-z]*)[\x00-\x20]*=([\'"]*)[\x00-\x20]*-moz-binding[\x00-\x20]*:#u', '$1=$2nomozbinding...', $data);

  // Only works in IE: <span style="width: expression(alert('Ping!'));"></span>
  $data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?expression[\x00-\x20]*\([^>]*+>#i', '$1>', $data);
  $data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?behaviour[\x00-\x20]*\([^>]*+>#i', '$1>', $data);
  $data = preg_replace('#(<[^>]+?)style[\x00-\x20]*=[\x00-\x20]*[`\'"]*.*?s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:*[^>]*+>#iu', '$1>', $data);

  // Remove namespaced elements (we do not need them)
  $data = preg_replace('#</*\w+:\w[^>]*+>#i', '', $data);

  do {
    // Remove really unwanted tags
    $old_data = $data;
    $data = preg_replace('#</*(?:applet|b(?:ase|gsound|link)|embed|frame(?:set)?|i(?:frame|layer)|l(?:ayer|ink)|meta|object|s(?:cript|tyle)|title|xml)[^>]*+>#i', '', $data);
  } while ($old_data !== $data);

  // we are done...
  return $data;
}

?>
<div class="container py-4">
  <h3 style="color: white;">What are your plans for traveling?</h3>
  <form id="contactForm" action="myplans.php" method="POST">
    <!-- Message input -->
    <div class="mb-3">
      <label style="color:white;" class="form-label" for="message">Describe it here, for your eyes only!</label>
      <textarea class="form-control" name="message" id="message" type="text" placeholder="Message" style="height: 10rem;" data-sb-validations="required"></textarea>
      <div class="invalid-feedback" data-sb-feedback="message:required">Your plan...</div>
    </div>
    <!-- Form submit button -->
    <div class="d-grid">
      <button class="btn btn-primary btn-lg" type="submit" name="myplans">Add a plan!</button>
    </div>
  </form>

  <h3 style="color: white;">My plans:</h3>
  <?php
  foreach ($goals as $goal) {
  ?>
    <div style="background-color: white; padding: 0.5%;margin: 0.5%; border-radius: 15px; border: 2px solid #034f84;">
      <p style="color: black;" title="<?php echo xss_clean($goal->goal); ?>"><?php echo htmlspecialchars($goal->goal, ENT_QUOTES, 'UTF-8'); ?></p>

    </div>
  <?php
  }
  ?>
</div>

<?php
include_once('header.php');
$error = '';

function publish($email, $comment, $helpfull)
{
  global $conn;
  $email = mysqli_real_escape_string($conn, $email);
  $comment = mysqli_real_escape_string($conn, $comment);
  $helpfull = mysqli_real_escape_string($conn, $helpfull);
  $query = "INSERT INTO feedbacks (email, message, helpfull)
				VALUES('$email', '$comment', '$helpfull');";
  if ($conn->query($query)) {
    return true;
  } else {
    return false;
  }
}

if (isset($_POST["submitFeedback"])) {
  if (publish($_POST["emailAddress"], $_POST["message"], $_POST["flexRadioDefault"])) {
    echo "<script>window.location.href='thankyou.php'</script>";
    die();
  } else {
    $error = "Something was wrong with the submitted data!";
  }
}
?>

<!-- Wrapper container -->
<div class="container py-4">

  <!-- Bootstrap 5 starter form -->
  <form id="contactForm" action="submitYourFeedback.php" method="POST">
    <!-- Email address input -->
    <div class="mb-3">
      <label style="color:white;" class="form-label" for="emailAddress">Email Address</label>
      <input class="form-control" name="emailAddress" id="emailAddress" type="email" placeholder="Email Address" data-sb-validations="required, email" />
      <div class="invalid-feedback" data-sb-feedback="emailAddress:required">Email Address is required.</div>
      <div class="invalid-feedback" data-sb-feedback="emailAddress:email">Email Address Email is not valid.</div>
    </div>

    <!-- Message input -->
    <div class="mb-3">
      <label style="color:white;" class="form-label" for="message">Message</label>
      <textarea class="form-control" name="message" id="message" type="text" placeholder="Message" style="height: 10rem;" data-sb-validations="required"></textarea>
      <div class="invalid-feedback" data-sb-feedback="message:required">Message is required.</div>
    </div>

    <label style="color:white;" class="form-label" for="message">Was this site helpfull?</label>
    <div class="form-check">
      <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" value="No">
      <label style="color:white;" class="form-check-label" for="flexRadioDefault1">
        No
      </label>
    </div>
    <div class="form-check">
      <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" value="Yes" checked>
      <label style="color:white;" class="form-check-label" for="flexRadioDefault2">
        Yes
      </label>
    </div>
    <!-- Form submissions success message -->
    <div class="d-none" id="submitSuccessMessage">
      <div class="text-center mb-3">Form submission successful!</div>
    </div>

    <!-- Form submissions error message -->
    <div class="d-none" id="submitErrorMessage">
      <div class="text-center text-danger mb-3">Error sending message!</div>
    </div>

    <!-- Form submit button -->
    <div class="d-grid">
      <button class="btn btn-primary btn-lg" type="submit" name="submitFeedback">Send us a message!</button>
    </div>

  </form>

</div>

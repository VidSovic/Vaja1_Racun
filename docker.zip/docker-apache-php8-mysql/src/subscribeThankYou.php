<?php
include_once('header.php');
?>
<div class="container">
	<div class="row">
		<div class="col">
		</div>
		<div class="col-5">
			<h2 style="color:white;">Thank you for subscribing!</h2>
		</div>
		<div class="col">
		</div>
	</div>
</div>
<?php
include_once('header.php');
?>
<!-- header section end -->
<!-- services section start -->
<div class="services_section layout_padding">
   <div class="container">
      <h1 style="color:white;" class="services_taital">Services </h1>
      <p style="color:white;" class="services_text">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration</p>
      <div class="services_section_2">
         <div class="row">
            <div class="col-md-4">
               <div><img src="images/img-1.png" class="services_img"></div>
               <div class="btn_main"><a href="#">Rafting</a></div>
            </div>
            <div class="col-md-4">
               <div><img src="images/img-2.png" class="services_img"></div>
               <div class="btn_main active"><a href="#">Hiking</a></div>
            </div>
            <div class="col-md-4">
               <div><img src="images/img-3.png" class="services_img"></div>
               <div class="btn_main"><a href="#">Camping</a></div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- services section end -->
<!-- footer section start -->
<div class="footer_section layout_padding">
   <div class="container">
      <div class="input_btn_main">
         <input type="text" class="mail_text" placeholder="Enter your email" name="Enter your email">
         <div class="subscribe_bt"><a href="#">Subscribe</a></div>
      </div>
      <div class="location_main">
         <div class="call_text"><img src="images/call-icon.png"></div>
         <div class="call_text"><a href="#">Call +01 1234567890</a></div>
         <div class="call_text"><img src="images/mail-icon.png"></div>
         <div class="call_text"><a href="#">demo@gmail.com</a></div>
      </div>
      <div class="social_icon">
         <ul>
            <li><a href="#"><img src="images/fb-icon.png"></a></li>
            <li><a href="#"><img src="images/twitter-icon.png"></a></li>
            <li><a href="#"><img src="images/linkedin-icon.png"></a></li>
            <li><a href="#"><img src="images/instagram-icon.png"></a></li>
         </ul>
      </div>
   </div>
</div>
<!-- footer section end -->
<!-- copyright section start -->
<div class="copyright_section">
   <div class="container">
      <p class="copyright_text">2020 All Rights Reserved. Design by <a href="https://html.design">Free html Templates</a></p>
   </div>
</div>
</body>

</html>
<?php
include_once('header.php');
?>
<div class="container">
	<div class="row">
		<div class="col">
		</div>
		<div class="col-5">
			<h2 style="color:white;">Thank you for your message! We will try to reply as soon as possible ;)</h2>
		</div>
		<div class="col">
		</div>
	</div>
</div>
<?php
include_once('header.php');
function username_exists($username)
{
	global $conn;
	$username = mysqli_real_escape_string($conn, $username);
	$query = "SELECT * FROM users WHERE username='$username'";
	$res = $conn->query($query);
	return mysqli_num_rows($res) > 0;
}

function email_exists($email)
{
	global $conn;
	$email = mysqli_real_escape_string($conn, $email);
	$query = "SELECT * FROM users WHERE email='$email'";
	$res = $conn->query($query);
	return mysqli_num_rows($res) > 0;
}



function register_user($username, $password, $email)
{
	global $conn;
	$username = mysqli_real_escape_string($conn, $username);
	$email = mysqli_real_escape_string($conn, $email);
	$pass = sha1($password);
	$query = "INSERT INTO users (email, username, password) VALUES ('$email', '$username', '$pass');";
	if ($conn->query($query)) {
		return true;
	} else {
		echo mysqli_error($conn);
		return false;
	}
}

$error = "";
if (isset($_POST["poslji"])) {

	$password = $_POST['password'];
	$number = preg_match('@[0-9]@', $password);
	$uppercase = preg_match('@[A-Z]@', $password);
	$lowercase = preg_match('@[a-z]@', $password);

	if ($_POST["password"] != $_POST["repeat_password"]) {
		$error = "Passwords do not match.";
	} else if (strlen($password) < 7 || !$number || !$uppercase || !$lowercase) {
		$error = "Password must contain at least 7 characters, number, lowercase and upercase character.";
	} else if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
		$error = "Invalid email address.";
	} else if (username_exists($_POST["username"])) {
		$error = "Username is already taken.";
	} else if (email_exists($_POST["email"])) {
		$error = "E-mail is already taken.";
	} else if (register_user($_POST["username"], $_POST["password"], $_POST["email"],)) {
		echo "<script>window.location.href='login.php'</script>";
		die();
	} else {
		$error = "Unexpected error occurred!";
	}
}

?>

<div class="container">
	<div class="row">
		<div class="col">
		</div>
		<div class="col-5">
			<h2 style="color:white;">Registration</h2>
			<form action="register.php" method="POST">
				<div class="form-group">
					<label style="color:white;" for="exampleInputEmail1">Username</label>
					<input type="username" class="form-control" name="username" placeholder="Enter username">
				</div>
				<div class="form-group">
					<label style="color:white;" for="exampleInputEmail1">E-mail</label>
					<input type="email" class="form-control" name="email" placeholder="Enter E-mail">
				</div>
				<div class="form-group">
					<label style="color:white;" for="exampleInputPassword1">Password</label>
					<input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Enter password">
				</div>
				<div class="form-group">
					<label style="color:white;" for="exampleInputPassword1">Repeat password</label>
					<input type="password" name="repeat_password" class="form-control" id="exampleInputPassword1" placeholder="Repeat password">
				</div>
				<p></p>
				<button type="submit" name="poslji" class="btn btn-primary">Register now!</button>
				<label style="color:red;"><?php echo $error; ?></label>
			</form>
		</div>
		<div class="col">
		</div>
	</div>
</div>

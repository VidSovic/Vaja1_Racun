<?php
include_once('header.php');

function validate_login($username, $password)
{
	global $conn;
	$username = mysqli_real_escape_string($conn, $username);
	$pass = sha1($password);
	$query = "SELECT * FROM users WHERE username='$username' AND password='$pass'";
	$res = $conn->query($query);
	if ($user_obj = $res->fetch_object()) {
		return $user_obj->id;
	}
	return -1;
}

$error = "";
if (isset($_POST["poslji"])) {
	if (($user_id = validate_login($_POST["username"], $_POST["password"])) >= 0) {
		$_SESSION["USER_ID"] = $user_id;
		echo "<script>window.location.href='index.php'</script>";
		die();
	} else {
		$error = "Login failed!";
	}
}
?>
<div class="container">
	<div class="row">
		<div class="col">
		</div>
		<div class="col-5">
			<h2 style="color:white;">Login page</h2>
			<form action="login.php" method="POST">
				<div class="form-group">
					<label style="color:white;" for="exampleInputEmail1">Username</label>
					<input type="username" class="form-control" name="username" placeholder="Enter your username">
				</div>
				<div class="form-group">
					<label style="color:white;" for="exampleInputPassword1">Password</label>
					<input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Enter your password">
				</div>
				<p></p>
				<button type="submit" name="poslji" class="btn btn-primary">Login</button>
				<label style="color:red;"><?php echo $error; ?></label>
			</form>
		</div>
		<div class="col">
		</div>
	</div>
</div>

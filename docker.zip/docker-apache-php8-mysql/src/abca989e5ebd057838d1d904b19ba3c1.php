<?php
include_once('header.php');

$feedbacks_id = [];

function get_feedbacks()
{
	global $conn;
	$query = "SELECT id FROM feedbacks;";
	$res = $conn->query($query);
	$feedbacks = array();
	while ($feedback = $res->fetch_object()) {
		array_push($feedbacks, $feedback);
	}
	return $feedbacks;
}
if (isset($_SESSION["USER_ID"])) {
	if ($_SESSION["USER_ID"] == 1) {
		$feedbacks = get_feedbacks();
	}
} else {
	echo "<script>window.location.href='login.php'</script>";
}

foreach ($feedbacks as $feedback) {
?>

	<div class="container">
		<div class="row">
			<div class="col">
			</div>
			<div class="col-6">
				<div class="id_feedback" id="id_feedback">
					<p id="id_feedback_p" style="color:white;"><?php echo $feedback->id; ?></p>
				</div>
				<hr />
			</div>
			<div class="col">
			</div>
		</div>
	<?php
}
	?>

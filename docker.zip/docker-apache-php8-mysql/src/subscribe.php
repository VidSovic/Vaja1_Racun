<?php
include_once('header.php');



function validate_login($username, $password)
{
    //DO NOTHING 
}

$error = "";
if (isset($_POST["poslji"])) {
    //Preveri prijavne podatke
    if (filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
        echo "<script>window.location.href='subscribeThankYou.php'</script>";
        die();
    } else {
        $error = "Invalid email address!";
    }
}
?>


<h3 style="color: red"><?php echo $error; ?></h3>

<?php
include_once('header.php');

if (isset($_SESSION["USER_ID"])) {
    if ($_SESSION["USER_ID"] == 1) {
?>
        <h3 style="color: red" title="ctf{52533448e88b27e3f29892bcad491e05}">Flag is here! Good job :)</h3>
<?php } else
        echo "<script>window.location.href='index.php'</script>";
} else {
    echo "<script>window.location.href='login.php'</script>";
} ?>

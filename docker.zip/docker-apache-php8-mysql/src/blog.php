<?php
include_once('header.php');
?>
<!-- header section end -->
<!-- blog section start -->
<div class="blog_section layout_padding margin_top_90">
   <div class="container">
      <h1 class="blog_taital">See Our Video</h1>
      <p class="blog_text">many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which</p>
      <div class="play_icon_main">
         <div class="play_icon"><a href="#"><img src="images/play-icon.png"></a></div>
      </div>
   </div>
</div>
<!-- blog section end -->
<!-- footer section start -->
<div class="footer_section layout_padding">
   <div class="container">
      <div class="input_btn_main">
         <input type="text" class="mail_text" placeholder="Enter your email" name="Enter your email">
         <div class="subscribe_bt"><a href="#">Subscribe</a></div>
      </div>
      <div class="location_main">
         <div class="call_text"><img src="images/call-icon.png"></div>
         <div class="call_text"><a href="#">Call +01 1234567890</a></div>
         <div class="call_text"><img src="images/mail-icon.png"></div>
         <div class="call_text"><a href="#">demo@gmail.com</a></div>
      </div>
      <div class="social_icon">
         <ul>
            <li><a href="#"><img src="images/fb-icon.png"></a></li>
            <li><a href="#"><img src="images/twitter-icon.png"></a></li>
            <li><a href="#"><img src="images/linkedin-icon.png"></a></li>
            <li><a href="#"><img src="images/instagram-icon.png"></a></li>
         </ul>
      </div>
   </div>
</div>
<!-- footer section end -->
<!-- copyright section start -->
<div class="copyright_section">
   <div class="container">
      <p class="copyright_text">2020 All Rights Reserved. Design by <a href="https://html.design">Free html Templates</a></p>
   </div>
</div>
</body>

</html>
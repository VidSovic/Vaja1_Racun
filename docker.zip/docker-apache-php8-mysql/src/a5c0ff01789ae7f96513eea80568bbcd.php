<?php
include_once('header.php');

function delete_feedbacks()
{
	global $conn;
	$query = "TRUNCATE feedbacks;";
	$conn->query($query);
    return -1;
}
if (isset($_SESSION["USER_ID"])) {
	if ($_SESSION["USER_ID"] == 1) {
		delete_feedbacks();
	}
} else {
	echo "<script>window.location.href='login.php'</script>";
}
